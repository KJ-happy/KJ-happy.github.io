
/// <reference types="vite/client" />

// Add PayPal SDK type definition
interface Window {
  paypal: {
    Buttons: (config: {
      style: {
        shape: string;
        color: string;
        layout: string;
        label: string;
      };
      createSubscription: (data: any, actions: any) => Promise<any>;
      onApprove: (data: any, actions: any) => void;
    }) => {
      render: (selector: string) => void;
    };
  };
}
