
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Add PayPal script to the document head
const addPayPalScript = () => {
  const script = document.createElement('script');
  script.src = "https://www.paypal.com/sdk/js?client-id=AUyuYORwKAeLceBptlWvi8p2mZ6LI_IVEsnrTBDCzZUEi2X4O9JGf6uVlCfZdOXEh7s33BLJCz0vaBqd&vault=true&intent=subscription";
  script.setAttribute('data-sdk-integration-source', 'button-factory');
  document.head.appendChild(script);
};

// Add the PayPal script when the app loads
addPayPalScript();

createRoot(document.getElementById("root")!).render(<App />);
