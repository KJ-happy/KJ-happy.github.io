
import { cn } from '@/lib/utils';
import React, { ReactNode } from 'react';

interface ServiceCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  className?: string;
}

const ServiceCard = ({ icon, title, description, className }: ServiceCardProps) => {
  return (
    <div className={cn('bg-white p-6 rounded-lg shadow-lg border border-gray-100 flex flex-col items-center text-center transition-transform hover:translate-y-[-5px]', className)}>
      <div className="text-brand-600 mb-4 text-4xl">{icon}</div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default ServiceCard;
