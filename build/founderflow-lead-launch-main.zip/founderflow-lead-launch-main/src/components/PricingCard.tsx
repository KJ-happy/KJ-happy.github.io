
import React, { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import Button from './Button';
import { Check } from 'lucide-react';

interface PricingCardProps {
  title: string;
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
  bannerTitle?: string;
  onClick?: () => void;
  className?: string;
  buttonText?: string;
  paypalButtonHtml?: string;
  paypalSubscriptionHtml?: string;
}

const PricingCard = ({
  title,
  price,
  description,
  features,
  isPopular = false,
  bannerTitle,
  onClick,
  className,
  buttonText = "Get Started",
  paypalButtonHtml,
  paypalSubscriptionHtml,
}: PricingCardProps) => {
  return (
    <div 
      className={cn(
        'bg-white rounded-xl shadow-lg border transition-all duration-300 hover:shadow-xl cursor-pointer overflow-hidden',
        isPopular ? 'border-brand-600 scale-105 z-10' : 'border-grey-200',
        className
      )}
      onClick={(paypalButtonHtml || paypalSubscriptionHtml) ? undefined : onClick}
    >
      {(isPopular || bannerTitle) && (
        <div className={cn(
          "py-1 px-3 text-center text-sm font-medium",
          bannerTitle === "Highest ROI" ? "bg-gradient-to-r from-brand-600 to-accent1-600 text-white" : "bg-brand-600 text-white"
        )}>
          {bannerTitle || "Most Popular"}
        </div>
      )}
      <div className="p-6 md:p-8">
        <h3 className="text-xl font-bold mb-2 text-grey-700">{title}</h3>
        <div className="flex items-baseline mb-4">
          <span className="text-3xl md:text-4xl font-bold text-grey-800">{price}</span>
        </div>
        <p className="text-grey-600 mb-6">{description}</p>
        <ul className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-accent1-600 mr-2 mt-0.5 shrink-0" />
              <span className="text-grey-600">{feature}</span>
            </li>
          ))}
        </ul>
        {bannerTitle === "Highest ROI" && (
          <div className="mb-6 bg-grey-50 border-l-4 border-brand-600 p-3 text-brand-700 font-medium">
            Get 11% more ROI with our Highest ROI package
          </div>
        )}
        
        {paypalButtonHtml ? (
          <div className="mt-4" dangerouslySetInnerHTML={{ __html: paypalButtonHtml }} onClick={(e) => e.stopPropagation()} />
        ) : paypalSubscriptionHtml ? (
          <div className="mt-4" dangerouslySetInnerHTML={{ __html: paypalSubscriptionHtml }} onClick={(e) => e.stopPropagation()} />
        ) : (
          <Button variant="primary" fullWidth>
            {buttonText}
          </Button>
        )}
      </div>
    </div>
  );
};

export default PricingCard;
