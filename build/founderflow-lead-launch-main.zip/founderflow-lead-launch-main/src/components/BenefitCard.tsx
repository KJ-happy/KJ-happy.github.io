
import { cn } from '@/lib/utils';
import React, { ReactNode } from 'react';

interface BenefitCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  className?: string;
}

const BenefitCard = ({ icon, title, description, className }: BenefitCardProps) => {
  return (
    <div className={cn('p-6 rounded-lg bg-white shadow-md border border-gray-100', className)}>
      <div className="text-accent1-600 mb-4 text-3xl">{icon}</div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default BenefitCard;
