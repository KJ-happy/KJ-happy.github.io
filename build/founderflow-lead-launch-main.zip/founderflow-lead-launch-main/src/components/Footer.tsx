
import React from 'react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-50 py-12 border-t border-gray-200">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo and Description - reduced to normal size */}
          <div>
            <div className="flex items-center mb-4">
              <img 
                src="/lovable-uploads/b5ed5d68-cb21-4901-8940-d25ef72501ab.png" 
                alt="FounderFlow AI Logo" 
                className="h-8 object-contain w-auto"
              />
            </div>
            <p className="text-gray-600 mb-4">
              Verified B2B leads delivered straight to your inbox. Quality decision-maker contacts for SaaS founders and B2B service providers.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-700">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-gray-600 hover:text-brand-600 transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-600 hover:text-brand-600 transition-colors">
                  Services
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="text-gray-600 hover:text-brand-600 transition-colors">
                  How It Works
                </a>
              </li>
              <li>
                <a href="#pricing" className="text-gray-600 hover:text-brand-600 transition-colors">
                  Pricing
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-600 hover:text-brand-600 transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Social & Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-gray-700">Connect</h3>
            <div className="flex items-center mb-4">
              <a 
                href="https://www.linkedin.com/in/kameshjanghel/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-brand-600 to-accent1-600 hover:from-brand-700 hover:to-accent1-700 text-white p-2 rounded-md transition-colors"
              >
                LinkedIn
              </a>
            </div>
            <p className="text-gray-600">
              <strong>Email:</strong> founderfloAI@gmail.com
            </p>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 text-sm mb-4 md:mb-0">
            &copy; {currentYear} FounderFlow AI. All rights reserved.
          </p>
          <div className="flex space-x-4 text-sm">
            <a href="#" className="text-gray-600 hover:text-brand-600 transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-600 hover:text-brand-600 transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
