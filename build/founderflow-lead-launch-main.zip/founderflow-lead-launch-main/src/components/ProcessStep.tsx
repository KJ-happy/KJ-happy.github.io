
import { cn } from '@/lib/utils';
import React, { ReactNode } from 'react';

interface ProcessStepProps {
  number: number;
  title: string;
  description: string;
  icon: ReactNode;
  className?: string;
}

const ProcessStep = ({ number, title, description, icon, className }: ProcessStepProps) => {
  return (
    <div className={cn('flex flex-col items-center text-center', className)}>
      <div className="bg-brand-600 text-white w-12 h-12 rounded-full flex items-center justify-center mb-4 text-xl font-bold">
        {number}
      </div>
      <div className="text-brand-600 text-3xl mb-3">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default ProcessStep;
