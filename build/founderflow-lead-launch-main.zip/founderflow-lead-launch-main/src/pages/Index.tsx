import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import SectionHeading from '@/components/SectionHeading';
import ServiceCard from '@/components/ServiceCard';
import ProcessStep from '@/components/ProcessStep';
import BenefitCard from '@/components/BenefitCard';
import PricingCard from '@/components/PricingCard';
import FAQItem from '@/components/FAQItem';
import ContactForm from '@/components/ContactForm';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';

import {
  FileText,
  UserCheck,
  Mail,
  MessageSquare,
  Clock,
  Calendar,
  DollarSign,
  CheckCircle,
  Search,
  User,
  ArrowRight,
  Info
} from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();

  // PayPal button HTML for Trial package
  const paypalButtonHtml = `<style>.pp-MCJ67VY4ZD87J{text-align:center;border:none;border-radius:0.25rem;min-width:11.625rem;padding:0 2rem;height:2.625rem;font-weight:bold;background-color:#FFD140;color:#000000;font-family:"Helvetica Neue",Arial,sans-serif;font-size:1rem;line-height:1.25rem;cursor:pointer;}</style>
<form action="https://www.paypal.com/ncp/payment/MCJ67VY4ZD87J" method="post" target="_blank" style="display:inline-grid;justify-items:center;align-content:start;gap:0.5rem;">
  <input class="pp-MCJ67VY4ZD87J" type="submit" value="Buy Now" />
  <img src=https://www.paypalobjects.com/images/Debit_Credit_APM.svg alt="cards" />
  <section style="font-size: 0.75rem;"> Powered by <img src="https://www.paypalobjects.com/paypal-ui/logos/svg/paypal-wordmark-color.svg" alt="paypal" style="height:0.875rem;vertical-align:middle;"/></section>
</form>`;

  // PayPal subscription HTML for Growth Plan package
  const paypalSubscriptionHtml = `<div id="paypal-button-container-P-02U60461YJ9077145NAS6B6A"></div>
<script src="https://www.paypal.com/sdk/js?client-id=AUyuYORwKAeLceBptlWvi8p2mZ6LI_IVEsnrTBDCzZUEi2X4O9JGf6uVlCfZdOXEh7s33BLJCz0vaBqd&vault=true&intent=subscription" data-sdk-integration-source="button-factory"></script>
<script>
  paypal.Buttons({
      style: {
          shape: 'rect',
          color: 'gold',
          layout: 'vertical',
          label: 'subscribe'
      },
      createSubscription: function(data, actions) {
        return actions.subscription.create({
          /* Creates the subscription */
          plan_id: 'P-02U60461YJ9077145NAS6B6A'
        });
      },
      onApprove: function(data, actions) {
        // Redirect to lead form after successful subscription
        window.location.href = '/lead-form';
      }
  }).render('#paypal-button-container-P-02U60461YJ9077145NAS6B6A'); // Renders the PayPal button
</script>`;

  // PayPal subscription HTML for Scale & ROI plan
  const scaleRoiSubscriptionHtml = `<div id="paypal-button-container-P-55N76535SG179992LNATAAYY"></div>
<script src="https://www.paypal.com/sdk/js?client-id=AUyuYORwKAeLceBptlWvi8p2mZ6LI_IVEsnrTBDCzZUEi2X4O9JGf6uVlCfZdOXEh7s33BLJCz0vaBqd&vault=true&intent=subscription" data-sdk-integration-source="button-factory"></script>
<script>
  paypal.Buttons({
      style: {
          shape: 'rect',
          color: 'gold',
          layout: 'vertical',
          label: 'subscribe'
      },
      createSubscription: function(data, actions) {
        return actions.subscription.create({
          /* Creates the subscription */
          plan_id: 'P-55N76535SG179992LNATAAYY'
        });
      },
      onApprove: function(data, actions) {
        // Redirect to lead form after successful subscription
        window.location.href = '/lead-form';
      }
  }).render('#paypal-button-container-P-55N76535SG179992LNATAAYY'); // Renders the PayPal button
</script>`;

  // Function to redirect to the lead form page
  const redirectToLeadForm = () => {
    navigate('/lead-form');
  };

  // Load PayPal scripts
  useEffect(() => {
    // This ensures the PayPal script loads properly when the component mounts
    const element = document.getElementById('paypal-button-container-P-02U60461YJ9077145NAS6B6A');
    const scaleElement = document.getElementById('paypal-button-container-P-55N76535SG179992LNATAAYY');
    
    if (typeof window.paypal !== 'undefined') {
      // Render Growth Plan button
      if (element) {
        try {
          window.paypal.Buttons({
            style: {
              shape: 'rect',
              color: 'gold',
              layout: 'vertical',
              label: 'subscribe'
            },
            createSubscription: function(data, actions) {
              return actions.subscription.create({
                plan_id: 'P-02U60461YJ9077145NAS6B6A'
              });
            },
            onApprove: function(data, actions) {
              // Redirect to lead form after successful subscription
              navigate('/lead-form', { state: { fromPayment: true } });
            }
          }).render('#paypal-button-container-P-02U60461YJ9077145NAS6B6A');
        } catch (error) {
          console.error('PayPal button rendering error:', error);
        }
      }
      
      // Render Scale & ROI Plan button
      if (scaleElement) {
        try {
          window.paypal.Buttons({
            style: {
              shape: 'rect',
              color: 'gold',
              layout: 'vertical',
              label: 'subscribe'
            },
            createSubscription: function(data, actions) {
              return actions.subscription.create({
                plan_id: 'P-55N76535SG179992LNATAAYY'
              });
            },
            onApprove: function(data, actions) {
              // Redirect to lead form after successful subscription
              navigate('/lead-form', { state: { fromPayment: true } });
            }
          }).render('#paypal-button-container-P-55N76535SG179992LNATAAYY');
        } catch (error) {
          console.error('Scale & ROI PayPal button rendering error:', error);
        }
      }
    }
  }, [navigate]);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      {/* Hero Section */}
      <section id="home" className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-brand-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Quality B2B Leads <span className="text-brand-600">Delivered Monthly</span>
              </h1>
              <p className="text-xl text-gray-600">
                Verified decision-maker contacts for B2B service providers and SaaS companies
              </p>
              <div className="pt-4 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Button 
                  size="lg" 
                  className="text-sm"
                  onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  Start Your Lead Generation
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-sm"
                  onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  Learn How It Works
                </Button>
              </div>
            </div>
            <div className="hidden lg:block">
              <img
                src="https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=800&q=80"
                alt="Business professionals discussing leads"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <SectionHeading
            title="What You Get"
            subtitle="Every month, we deliver high-quality B2B leads directly to your inbox, ready for your outreach campaigns."
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ServiceCard
              icon={<UserCheck size={48} />}
              title="Verified Leads"
              description="75-100 verified decision-maker contacts every month, carefully vetted to match your ideal customer profile."
            />
            <ServiceCard
              icon={<FileText size={48} />}
              title="Complete Information"
              description="Full name, title, company, email, and LinkedIn profile for each lead, giving you multiple ways to connect."
            />
            <ServiceCard
              icon={<MessageSquare size={48} />}
              title="Ready Templates"
              description="Custom email and LinkedIn connection templates tailored to your industry and offering for higher response rates."
            />
          </div>

          <div className="mt-12 text-center">
            <Button
              size="lg"
              onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
            >
              View Pricing
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeading
            title="Our Simple Process"
            subtitle="We've streamlined the lead generation process so you can focus on what matters most: closing deals."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <ProcessStep
              number={1}
              icon={<MessageSquare size={36} />}
              title="Consultation"
              description="Provide your ideal customer profile via our simple form"
            />
            <ProcessStep
              number={2}
              icon={<Search size={36} />}
              title="Research"
              description="We use advanced tools to identify decision-makers matching your criteria"
            />
            <ProcessStep
              number={3}
              icon={<ArrowRight size={36} />}
              title="Delivery"
              description="Receive your first batch of leads within 24 hours of payment"
            />
            <ProcessStep
              number={4}
              icon={<Calendar size={36} />}
              title="Ongoing"
              description="Get fresh leads monthly on your preferred delivery date"
            />
          </div>
        </div>
      </section>

      {/* Value Proposition Section */}
      <section id="benefits" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <SectionHeading
            title="How This Benefits Your Business"
            subtitle="Our leads don't just fill your CRM—they fuel real business growth and save you valuable time."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <BenefitCard
              icon={<Clock size={32} />}
              title="Time Savings"
              description="Save 15+ hours per week on prospecting and research, allowing you to focus on closing deals instead of finding them."
            />
            <BenefitCard
              icon={<User size={32} />}
              title="Quality Conversations"
              description="Connect with actual decision-makers, not gatekeepers, increasing your success rate and shortening your sales cycle."
            />
            <BenefitCard
              icon={<ArrowRight size={32} />}
              title="Predictable Pipeline"
              description="Maintain a consistent flow of new business opportunities with regular lead deliveries each month."
            />
            <BenefitCard
              icon={<DollarSign size={32} />}
              title="Clear ROI"
              description="Just one new client covers the cost of the service many times over. Our average client sees a 27% increase in meetings booked."
            />
            <BenefitCard
              icon={<Clock size={32} />}
              title="Delivered Within 24 Hours"
              description="Quality leads delivered within 24 hours of first payment. Schedule future batches at your convenience."
            />
          </div>
        </div>
      </section>

      {/* Guarantee Section */}
      <section id="guarantee" className="py-12 md:py-16 bg-brand-50">
        <div className="container mx-auto px-4 text-center">
          <div className="inline-block text-brand-600 mb-4">
            <CheckCircle size={48} />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Our Satisfaction Guarantee
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            If the leads don't match your criteria or expectations, we'll replace them at no additional cost. Your satisfaction is our priority.
          </p>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <SectionHeading
            title="Simple, Transparent Pricing"
            subtitle="No hidden fees, no long-term contracts. Just quality leads at predictable prices."
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
            <PricingCard
              title="Trial Package"
              price="$30 one-time"
              description="10 Verified B2B Leads"
              features={[
                "10 verified decision-maker leads",
                "Complete contact information",
                "Email & LinkedIn message templates"
              ]}
              paypalButtonHtml={paypalButtonHtml}
            />
            <PricingCard
              title="Growth Plan"
              price="$299/month"
              description="75 Verified B2B Leads"
              features={[
                "75 verified decision-maker leads monthly",
                "Complete contact information",
                "Email & LinkedIn message templates",
                "No contracts, cancel recurring payments anytime"
              ]}
              buttonText="Start My Plan"
              paypalSubscriptionHtml={paypalSubscriptionHtml}
            />
            <PricingCard
              title="Scale & ROI Plan"
              price="$359/month"
              description="100 Verified B2B Leads"
              features={[
                "100 verified decision-maker leads monthly",
                "Complete contact information",
                "Email & LinkedIn message templates",
                "No contracts, cancel recurring payments anytime"
              ]}
              bannerTitle="Highest ROI"
              buttonText="Start My Plan"
              paypalSubscriptionHtml={scaleRoiSubscriptionHtml}
            />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="col-span-1 md:col-span-2">
              <h2 className="text-3xl font-bold mb-6">About FounderFlow AI</h2>
              <p className="text-gray-600 mb-6">
                FounderFlow AI was created by experienced B2B sales and marketing professionals who understand the challenges of lead generation firsthand. We combine advanced research methodologies with rigorous verification processes to deliver high-quality, conversion-ready leads. Born from our own frustrations with overpriced and unreliable lead generation services, FounderFlow AI represents our solution: consistently delivering verified decision-maker contacts each month at transparent pricing that makes sense for growing businesses.
              </p>
              <div className="flex items-center space-x-4">
                <Avatar className="w-12 h-12">
                  <AvatarImage src="/lovable-uploads/dc39a72b-b015-496c-b0e3-60c45986cabe.png" alt="Kamesh Janghel" />
                  <AvatarFallback>KJ</AvatarFallback>
                </Avatar>
                <a
                  href="https://www.linkedin.com/in/kameshjanghel/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-[#0077B5] text-white px-6 py-3 rounded-md hover:bg-[#005e8d] transition-colors"
                >
                  Connect on LinkedIn
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionHeading
            title="Frequently Asked Questions"
            subtitle="Everything you need to know about our lead generation service"
          />

          <div className="max-w-3xl mx-auto">
            <FAQItem
              question="How are the leads verified?"
              answer="We use a multi-step verification process that includes checking email deliverability, confirming job titles through LinkedIn and company websites, and ensuring the leads match your specified criteria."
            />
            <FAQItem
              question="What industries do you cover?"
              answer="We specialize in B2B leads across technology, SaaS, professional services, marketing, consulting, and finance industries. If your target audience is in another industry, contact us to discuss your specific needs."
            />
            <FAQItem
              question="How do I receive my leads?"
              answer="Leads are delivered via a secure spreadsheet on your preferred delivery date each month. You'll receive an email notification when new leads are ready."
            />
            <FAQItem
              question="Can I request specific criteria for my leads?"
              answer="Absolutely! Our onboarding form allows you to specify industry, company size, job titles, geographic locations, and other targeting criteria to ensure you receive leads that match your ideal customer profile."
            />
            <FAQItem
              question="What if I want to cancel?"
              answer="There are no long-term contracts. You can cancel your subscription at any time through your account dashboard or by emailing our support team."
            />
            <FAQItem
              question="Do you offer a satisfaction guarantee?"
              answer="Yes! If you're not satisfied with your leads, just let us know and we'll work to make it right by providing replacement leads that better match your criteria at no additional cost."
            />
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <SectionHeading
            title="Questions? Reach Out"
            subtitle="We're here to help with any questions about our lead generation service."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-4">Contact Information</h3>
              <p className="text-gray-600 mb-6">
                The fastest way to reach us is through the contact form or by sending an email directly. We aim to respond to all inquiries within 24 hours during business days.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Mail className="h-6 w-6 text-brand-600 mr-3 mt-0.5" />
                  <span className="text-gray-600">founderfloAI@gmail.com</span>
                </div>
                <div className="flex items-start">
                  <Info className="h-6 w-6 text-brand-600 mr-3 mt-0.5" />
                  <span className="text-gray-600">Based in the United States</span>
                </div>
              </div>
              <div className="mt-8">
                <a
                  href="https://www.linkedin.com/in/kameshjanghel/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-[#0077B5] text-white px-6 py-3 rounded-md hover:bg-[#005e8d] transition-colors"
                >
                  Connect on LinkedIn
                </a>
              </div>
            </div>
            <div>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
