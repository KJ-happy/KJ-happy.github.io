
import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const LeadForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const fromPayment = location.state?.fromPayment;
  
  useEffect(() => {
    // Redirect to the Google Form
    window.location.href = 'https://docs.google.com/forms/d/1G-38rx7drzHnp4j0pj5K16C1vmZbQSxfQq3Uf7hxMcE/edit';
  }, []);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="text-center p-8">
        <h1 className="text-2xl font-bold mb-4">Redirecting to Lead Form...</h1>
        <p className="mb-4">Please wait while we redirect you to our intake form.</p>
        <button 
          onClick={() => navigate('/')}
          className="text-brand-600 hover:text-brand-800 font-medium"
        >
          Return to homepage
        </button>
      </div>
    </div>
  );
};

export default LeadForm;
