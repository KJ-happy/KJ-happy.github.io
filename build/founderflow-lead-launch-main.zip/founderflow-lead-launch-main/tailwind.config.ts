
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
				sidebar: {
					DEFAULT: 'hsl(var(--sidebar-background))',
					foreground: 'hsl(var(--sidebar-foreground))',
					primary: 'hsl(var(--sidebar-primary))',
					'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
					accent: 'hsl(var(--sidebar-accent))',
					'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
					border: 'hsl(var(--sidebar-border))',
					ring: 'hsl(var(--sidebar-ring))'
				},
				brand: {
					50: '#e6f3ff',
					100: '#cce7ff',
					200: '#99cfff',
					300: '#66b7ff',
					400: '#339fff',
					500: '#007BFF', // Adjusted to match logo blue
					600: '#0062da',
					700: '#0052b5',
					800: '#004290',
					900: '#00316b',
					950: '#00244d',
				},
				accent1: {
					50: '#e6faf2',
					100: '#ccf5e5',
					200: '#99ebcb',
					300: '#66e0b1',
					400: '#33d697',
					500: '#14B888', // Adjusted to match logo green
					600: '#10936d',
					700: '#0d7a5b',
					800: '#0a6249',
					900: '#084937',
					950: '#053124',
				},
				grey: {
					50: '#F2F4F7', // Lighter grey from logo
					100: '#E5E8ED',
					200: '#D9DEE5',
					300: '#BDC5D1',
					400: '#A7B0BC',
					500: '#7D8999', // Main grey from logo
					600: '#5A636F',
					700: '#464D57',
					800: '#32373E',
					900: '#1E2226',
				}
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out'
			},
			fontFamily: {
				'montserrat': ['Montserrat', 'sans-serif'],
				'opensans': ['Open Sans', 'sans-serif'],
			},
			backgroundImage: {
				'hero-pattern': "linear-gradient(to bottom, rgba(10, 10, 15, 0.9), rgba(10, 10, 15, 0.8))"
			}
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
